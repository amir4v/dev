from django.db import models


class ModelName(models.Model):
    field_name = models.CharField(max_length=100)
